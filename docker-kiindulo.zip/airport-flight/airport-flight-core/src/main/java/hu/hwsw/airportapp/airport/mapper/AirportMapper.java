package hu.hwsw.airportapp.airport.mapper;

import hu.hwsw.airportapp.airport.model.Airport;
import hu.hwsw.airport.dto.airport.AirportDTO;
import hu.hwsw.airport.dto.airport.NewAirportDTO;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AirportMapper {

	AirportMapper INSTANCE = Mappers.getMapper(AirportMapper.class);
	
	AirportDTO airportToDto(Airport airport);
	
	void updateFromDto(NewAirportDTO dto, @MappingTarget Airport airport);
}
