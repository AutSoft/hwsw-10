package hu.hwsw.airportapp.airport.web;

import hu.hwsw.airportapp.airport.mapper.FlightMapper;
import hu.hwsw.airportapp.airport.service.FlightService;
import hu.hwsw.airport.dto.flight.FlightDTO;
import hu.hwsw.airport.dto.flight.NewFlightDTO;
import hu.hwsw.airport.dto.flight.NewFlightWithNewAirportsDTO;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class FlightController {

    private FlightService flightService;

    public FlightController(FlightService flightService) {
        this.flightService = flightService;
    }

    /* Test data:
     * {
	"fromAirport":{"name": "Liszt Ferenc", "iata": "BUD"},
	"toAirport":{"name": "Kennedy", "iata": "JFK"},
	"newFlight": {
		"flightNumber": "ABC123",
		"capacity": 120,
		"flightTime": 8,
		"averageDelay": 0.5,
		"fromAirportId": -1,
		"toAirportId": -1
	}
}
     */
    @PostMapping("/flights/withAirports")
    public FlightDTO createFlight(@RequestBody NewFlightWithNewAirportsDTO newFlightWithNewAirportsDTO){
        return FlightMapper.INSTANCE.flightToDto(flightService.createFlightWithAirports(newFlightWithNewAirportsDTO));
    }
    
    @PostMapping("/flights/search")
    public List<FlightDTO> searchFlights(@RequestBody FlightDTO example){
    	FlightMapper mapper = FlightMapper.INSTANCE;
		return mapper.flightsToDto(flightService.searchFlights(mapper.dtoToFlight(example)));
    }

    @GetMapping("/airports/{airportId}/arriving-flights")
    public List<FlightDTO> getArrivingFlightsByAirportId(@PathVariable Long airportId) {
        return FlightMapper.INSTANCE.flightsToDto(flightService.getArrivingFlightsByAirportId(airportId));
    }

    @GetMapping("/airports/{airportId}/departing-flights")
    public List<FlightDTO> getDepartingFlightsByAirportId(@PathVariable Long airportId) {
        return FlightMapper.INSTANCE.flightsToDto(flightService.getDepartingFlightsByAirportId(airportId));
    }

    @PostMapping("/flights")
    public FlightDTO createFlight(@RequestBody NewFlightDTO newFlight){
        return FlightMapper.INSTANCE.flightToDto(flightService.createFlight(newFlight));
    }

    @GetMapping("/flights")
    public List<FlightDTO> getFlights() {
        String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        System.out.println(username);
        return FlightMapper.INSTANCE.flightsToDto(flightService.getFlights());
    }

    @GetMapping("/flights/{id}")
    public FlightDTO getFlightById(@PathVariable Long id) {
        return FlightMapper.INSTANCE.flightToDto(flightService.getFlightById(id));
    }

    @PutMapping("/flights/{id}")
    public FlightDTO updateFlightById(@PathVariable Long id, @RequestBody @Valid NewFlightDTO newFlight) {
        return FlightMapper.INSTANCE.flightToDto(flightService.updateFlightById(id, newFlight));
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("/flights/{id}")
    public void deleteFlightById(@PathVariable Long id){
        flightService.deleteFlightById(id);
    }

}
