package hu.hwsw.airportapp.user.mapper;

import hu.hwsw.airportapp.user.dto.UserDTO;
import hu.hwsw.airportapp.user.model.User;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface UserMapper {

    UserMapper INSTANCE = Mappers.getMapper(UserMapper.class);

    UserDTO userToDto(User user);

}
