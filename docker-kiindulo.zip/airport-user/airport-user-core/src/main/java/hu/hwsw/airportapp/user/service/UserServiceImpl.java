package hu.hwsw.airportapp.user.service;

import hu.hwsw.airportapp.user.model.User;
import hu.hwsw.airportapp.user.repository.UserRepository;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User getUserByUsername(String username) {
        return userRepository.findById(username).orElseThrow(() -> new UsernameNotFoundException(username));
    }

}
