package hu.hwsw.airportapp.common.feign;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class HeaderForwarderInterceptorsConfigurer {

    @Bean(name = "acceptLanguageHeaderForwarderInterceptor")
    public HeaderForwarderInterceptor acceptLanguageHeaderForwarderInterceptor(){
        return new HeaderForwarderInterceptor("Accept-Language");
    }

    @Bean(name = "authorizationHeaderForwarderInterceptor")
    public HeaderForwarderInterceptor authorizationHeaderForwarderInterceptor(){
        return new HeaderForwarderInterceptor("Authorization");
    }

}
