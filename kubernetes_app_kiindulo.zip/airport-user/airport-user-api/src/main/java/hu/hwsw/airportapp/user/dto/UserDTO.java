package hu.hwsw.airportapp.user.dto;

import java.util.Set;

public class UserDTO {

    private String username;
    private boolean enabled;

    private Set<AuthorityDTO> authorities;

    public UserDTO() {
    }

    public UserDTO(String username, boolean enabled, Set<AuthorityDTO> authorities) {
        this.username = username;
        this.enabled = enabled;
        this.authorities = authorities;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public Set<AuthorityDTO> getAuthorities() {
        return authorities;
    }

    public void setAuthorities(Set<AuthorityDTO> authorities) {
        this.authorities = authorities;
    }
}
