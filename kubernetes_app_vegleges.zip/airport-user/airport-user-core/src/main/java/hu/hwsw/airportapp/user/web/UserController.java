package hu.hwsw.airportapp.user.web;

import hu.hwsw.airportapp.user.dto.UserDTO;
import hu.hwsw.airportapp.user.mapper.UserMapper;
import hu.hwsw.airportapp.user.service.UserService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/users")
public class UserController {

    private UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/{username}")
    public UserDTO getUserByUsername(@PathVariable String username) {
        return UserMapper.INSTANCE.userToDto(userService.getUserByUsername(username));
    }

}
