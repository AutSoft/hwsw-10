package hu.hwsw.airportapp.user.service;

import hu.hwsw.airportapp.user.model.User;

public interface UserService {

    User getUserByUsername(String username);

}
